# Cric Warriors — AndroidIDE Testing Project

Branding: **Cric Warriors**

Open the folder containing `settings.gradle` as the project root.
Do not open the `app` folder itself.

The project includes a root `gradlew` launcher because AndroidIDE's Build action invokes `./gradlew`.

Build output:
`app/build/outputs/apk/debug/app-debug.apk`
